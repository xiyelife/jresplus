亲！
	您所打开的这个工程（quick_start_mvc）主要包含以下内容：
	1，使用mvc搭建web开发环境所需的jar包(WebApp/WEB-INF/lib/)；
	2，jresplus-mvc的视图目录规范（WEB-INF/views/screen/,WEB-INF/views/layout/）；
	3，jresplus开发的参数化机制（WEB-INF/conf/server.properties）；
	4，jresplus-mvc的异常拦截器配置、资源文件配置；
	5，以ehcache为例展示如何使用ehcache实现页面静态化；
	6，展示了Bigpipe的特性；
	7，展示了PageStatic的特性；
	8，展示了沙箱式页面复用的特性（$contain）；
	9，展示了使用URLBroker引入资源的方式；
	10，jresplus-mvc在web.xml中的配置

	在查看过程中有不明白的地方，可以在https://github.com/hundsun/jresplus/上给我留言。